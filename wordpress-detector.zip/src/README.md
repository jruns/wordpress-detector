# wordpress-detector
A simple chrome extension that lets you know if the site you are currently on is a Wordpress site.
